<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *Must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>SISFO UINAM | <?php echo e($title ?? ''); ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('img/icons')); ?>/si.png" >

    <!-- Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('templates/frontend/clever')); ?>/style.css">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner"></div>
    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">

        <!-- Top Header Area -->
        <div class="top-header-area d-flex justify-content-between align-items-center">
            <!-- Contact Info -->
            <div class="contact-info">
                <a href="#"><span>Email:</span> hmj.si@uin-alauddin.ac.id</a>
            </div>
            <!-- Follow Us -->
            <div class="follow-us">
                <span>Follow us</span>
                <a href="https://www.facebook.com/hmjsi.uinam" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="https://instagram.com/hmjsi.uinam?utm_medium=copy_link" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="https://twitter.com/hmjsi_uinam?s=21" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href="https://youtube.com/channel/UCMTV4qMNUkepi6n5eTQeoYw" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                
            </div>
        </div>

        <!-- Navbar Area -->
        <?php echo $__env->make('layouts.frontend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <!-- ##### Header Area End ##### -->

    <?php echo $__env->yieldContent('content'); ?>

    <!-- ##### Footer Area Start ##### -->
    <?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ##### Footer Area End ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="<?php echo e(asset('templates/frontend/clever')); ?>/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="<?php echo e(asset('templates/frontend/clever')); ?>/js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo e(asset('templates/frontend/clever')); ?>/js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="<?php echo e(asset('templates/frontend/clever')); ?>/js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="<?php echo e(asset('templates/frontend/clever')); ?>/js/active.js"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html><?php /**PATH E:\HMJ-SI\laraschool-test\laraschool-master\resources\views/layouts/frontend/app.blade.php ENDPATH**/ ?>