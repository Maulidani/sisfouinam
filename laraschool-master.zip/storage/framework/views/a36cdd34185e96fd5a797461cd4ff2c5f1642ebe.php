

<?php $__env->startSection('content'); ?>
    <div class="clever-catagory blog-details bg-img d-flex align-items-center justify-content-center p-3 height-400"
        style="background-image: url(<?php echo e(asset($agenda->getThumbnail())); ?>);">
        <div class="blog-details-headline">
            <h3><?php echo e($agenda->judul); ?></h3>
            <div class="meta d-flex align-items-center justify-content-center">
                <a href="#"><?php echo e($agenda->user->author); ?></a>
                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                <a href="#"><?php echo e(\Carbon\Carbon::parse($agenda->tgl_mulai)->isoFormat('dddd, D MMMM Y')); ?></a>
            </div>
        </div>
    </div>
    <!-- ##### Catagory Area End ##### -->

    <!-- ##### Blog Details Content ##### -->
    <div class="blog-details-content section-padding-100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-8">
                    <!-- Blog Details Text -->
                    <div class="blog-details-text">
                        <?php echo $agenda->deskripsi; ?>

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app',[
'title' => 'Baca Artikel',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HMJ-SI\laraschool-test\laraschool-master\resources\views/agenda/show.blade.php ENDPATH**/ ?>